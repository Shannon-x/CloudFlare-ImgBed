// 当页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 每秒检查一次Vue是否加载完成以及页脚元素是否存在
    const checkInterval = setInterval(function() {
        // 查找页脚中所有外部链接
        const footerLinks = document.querySelectorAll('.footer-name, .footer a[href*="github"]');
        if (footerLinks && footerLinks.length > 0) {
            // 移除所有找到的GitHub链接
            footerLinks.forEach(link => {
                // 如果是链接自身，直接移除
                if (link.tagName === 'A') {
                    const parent = link.parentNode;
                    parent.removeChild(link);
                } 
                // 如果是包含链接的元素，清空其内容
                else if (link.querySelector('a')) {
                    link.innerHTML = '';
                }
            });
            
            // 移除"for You!"等文本节点
            const footerElements = document.querySelectorAll('.footer');
            footerElements.forEach(footer => {
                const childNodes = Array.from(footer.childNodes);
                childNodes.forEach(node => {
                    if (node.nodeType === Node.TEXT_NODE && node.textContent.includes('for You')) {
                        footer.removeChild(node);
                    }
                });
            });
            
            clearInterval(checkInterval);
        }
    }, 1000);
}); 