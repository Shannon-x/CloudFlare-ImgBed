// S3连接测试组件
// 该组件提供S3连接测试和格式切换功能

/**
 * 测试S3连接
 * @param {Object} s3Config - S3配置信息
 * @returns {Promise<Object>} - 测试结果
 */
async function testS3Connection(s3Config) {
    try {
        const response = await fetch('/api/manage/test/s3', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(s3Config),
        });

        const result = await response.json();
        return result;
    } catch (error) {
        console.error('测试S3连接时出错:', error);
        return {
            success: false,
            message: `请求失败: ${error.message}`
        };
    }
}

// 导出函数供前端使用
window.s3TestUtils = {
    testS3Connection
};

// 当页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 每秒检查一次Vue是否加载完成以及S3配置组件是否存在
    const checkInterval = setInterval(function() {
        if (document.querySelector('.s3-settings-card')) {
            initS3TestComponent();
            clearInterval(checkInterval);
        }
    }, 1000);
});

function initS3TestComponent() {
    // 查找所有S3配置卡片
    const s3Cards = document.querySelectorAll('.s3-settings-card');
    
    s3Cards.forEach(function(card, index) {
        // 查找表单容器
        const formContainer = card.querySelector('.s3-form-container');
        if (!formContainer) return;
        
        // 获取输入字段
        const accessKeyField = formContainer.querySelector('input[placeholder*="Access Key"]');
        const secretKeyField = formContainer.querySelector('input[placeholder*="Secret Key"]');
        const endpointField = formContainer.querySelector('input[placeholder*="Endpoint"]');
        const bucketField = formContainer.querySelector('input[placeholder*="Bucket"]');
        const regionField = formContainer.querySelector('input[placeholder*="Region"]');
        
        // 创建格式切换开关
        const formatSwitch = document.createElement('div');
        formatSwitch.className = 's3-format-switch';
        formatSwitch.innerHTML = `
            <label style="display: flex; align-items: center; margin-bottom: 10px;">
                <span style="margin-right: 10px;">存储桶格式:</span>
                <select class="s3-format-select" style="padding: 8px; border-radius: 4px; border: 1px solid #dcdfe6;">
                    <option value="path">路径式 (endpoint/bucket/file)</option>
                    <option value="virtualHost">虚拟主机式 (bucket.endpoint/file)</option>
                </select>
            </label>
        `;
        
        // 创建测试按钮
        const testButton = document.createElement('button');
        testButton.className = 's3-test-button';
        testButton.textContent = '测试连接';
        testButton.style.cssText = 'margin-left: 10px; padding: 8px 16px; background-color: #409eff; color: white; border: none; border-radius: 4px; cursor: pointer;';
        
        // 找到适合插入测试按钮的位置（通常是保存按钮旁边）
        const saveButton = formContainer.querySelector('button[type="submit"]');
        if (saveButton) {
            saveButton.parentNode.appendChild(testButton);
            // 在表单末尾添加格式切换开关
            formContainer.appendChild(formatSwitch);
            
            // 获取s3Format字段的值（如果存在）并设置选择器的默认值
            const formatSelect = formatSwitch.querySelector('.s3-format-select');
            // 默认选择路径式
            formatSelect.value = 'path';
            
            // 添加测试按钮点击事件
            testButton.addEventListener('click', function(e) {
                e.preventDefault();
                
                // 获取当前输入的值
                const testData = {
                    accessKeyId: accessKeyField ? accessKeyField.value : '',
                    secretAccessKey: secretKeyField ? secretKeyField.value : '',
                    endpoint: endpointField ? endpointField.value : '',
                    bucketName: bucketField ? bucketField.value : '',
                    region: regionField ? regionField.value : 'auto',
                    s3Format: formatSelect.value
                };
                
                // 验证必填字段
                if (!testData.accessKeyId || !testData.secretAccessKey || !testData.endpoint || !testData.bucketName) {
                    showMessage('请填写所有必要的S3配置信息', 'error');
                    return;
                }
                
                // 显示加载中
                testButton.disabled = true;
                testButton.textContent = '测试中...';
                
                // 发送测试请求
                fetch('/api/manage/test/s3', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(testData)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage(`连接成功！示例URL: ${data.exampleUrl}`, 'success');
                    } else {
                        showMessage(`连接失败: ${data.message}`, 'error');
                    }
                })
                .catch(error => {
                    showMessage(`请求错误: ${error.message}`, 'error');
                })
                .finally(() => {
                    // 恢复按钮状态
                    testButton.disabled = false;
                    testButton.textContent = '测试连接';
                });
            });
        }
    });
}

function showMessage(message, type) {
    // 检查是否存在ElementUI的Message组件
    if (window.ELEMENT && ELEMENT.Message) {
        ELEMENT.Message({
            message: message,
            type: type,
            duration: 3000
        });
    } else {
        // 后备方案，创建一个简单的消息提示
        const msgBox = document.createElement('div');
        msgBox.style.cssText = `
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            padding: 10px 20px;
            border-radius: 4px;
            background-color: ${type === 'success' ? '#67C23A' : '#F56C6C'};
            color: white;
            z-index: 9999;
            box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
        `;
        msgBox.textContent = message;
        document.body.appendChild(msgBox);
        
        setTimeout(() => {
            msgBox.style.opacity = '0';
            msgBox.style.transition = 'opacity 0.5s';
            setTimeout(() => {
                document.body.removeChild(msgBox);
            }, 500);
        }, 3000);
    }
} 