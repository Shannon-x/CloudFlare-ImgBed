import { S3Client, ListBucketsCommand } from "@aws-sdk/client-s3";

export async function onRequest(context) {
    const {
        request,
        env,
    } = context;

    // 只接受POST请求
    if (request.method !== 'POST') {
        return new Response('Method not allowed', { status: 405 });
    }

    try {
        // 获取请求体
        const body = await request.json();
        const { endpoint, accessKeyId, secretAccessKey, bucketName, region, s3Format } = body;

        // 验证必须的参数
        if (!endpoint || !accessKeyId || !secretAccessKey || !bucketName) {
            return new Response(JSON.stringify({
                success: false,
                message: '缺少必要的参数'
            }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // 创建S3客户端
        const s3Client = new S3Client({
            region: region || "auto",
            endpoint,
            credentials: {
                accessKeyId,
                secretAccessKey
            },
            forcePathStyle: s3Format === 'path'
        });

        // 测试连接
        try {
            // 尝试列出所有桶
            const command = new ListBucketsCommand({});
            const response = await s3Client.send(command);
            
            // 检查指定的桶是否存在
            const bucketExists = response.Buckets?.some(bucket => bucket.Name === bucketName);
            
            if (!bucketExists) {
                return new Response(JSON.stringify({
                    success: false,
                    message: `连接成功，但找不到指定的存储桶: ${bucketName}`
                }), {
                    status: 200,
                    headers: { 'Content-Type': 'application/json' }
                });
            }

            // 构建示例URL
            const s3ServerDomain = endpoint.replace(/https?:\/\//, "");
            let exampleUrl = '';
            
            if (s3Format === 'path') {
                // 路径式
                exampleUrl = `${endpoint}/${bucketName}/example.jpg`;
            } else {
                // 虚拟主机式
                exampleUrl = `https://${bucketName}.${s3ServerDomain}/example.jpg`;
            }

            return new Response(JSON.stringify({
                success: true,
                message: '连接成功！存储桶可用。',
                exampleUrl
            }), {
                status: 200,
                headers: { 'Content-Type': 'application/json' }
            });
        } catch (error) {
            return new Response(JSON.stringify({
                success: false,
                message: `连接测试失败: ${error.message}`
            }), {
                status: 200,
                headers: { 'Content-Type': 'application/json' }
            });
        }
    } catch (error) {
        return new Response(JSON.stringify({
            success: false,
            message: `请求处理失败: ${error.message}`
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' }
        });
    }
} 