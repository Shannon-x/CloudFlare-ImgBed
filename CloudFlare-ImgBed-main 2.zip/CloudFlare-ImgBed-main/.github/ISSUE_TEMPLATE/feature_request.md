---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

# 功能需求
> 尽可能详细描述您的需求


# 应用场景
> web or api...


# 可行方案
> 您对该功能的实现有哪些想法
