---
name: Help wanted issue template
about: Help wanted template.
title: ''
labels: ''
assignees: ''

---

# 问题描述
> 建议出问题先更新到最新版本，查看已有issue；请在labels设置中加上问题类型


# 上传方式
> web or api


# 上传渠道
> Telegram, Cloudflare R2等


# 辅助材料
> 上传接口请求、响应截图，环境变量设置截图等，尽可能详细
